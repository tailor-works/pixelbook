Pixelbook Softwares<br />
by Edward (brizzalnt) Taylor<br />
of Open Ideas.<br />
<br />
Written in Rust<br />
Previous Versions Written in<br />
Swift, Xojo, Javascript...<br />
To Test Speed / Compatability.<br />


Updates ...<br />
Note : This is Unfinished Work<br />
--------------------
Jun 4th 25 - 5:00pm  GMT - Created Pixelbook Project .<br />
Jun 5th 25 - 7:54am  GMT - Added Start to Nibb .<br />
Jun 5th 25 - 12:32pm GMT - Added idea for Raycaster from Google Gemini . <br />
Jun 5th 25 - 8:31pm  GMT - main.rs Updated .<br />
Jun 6th 25 - 9:29pm  GMT - files.rs added and updated . <br />
Jun 6th 25 - 11:57am GMT - Added an arraystore to files.rs . <br />
Jun 6th 25 - 4:48pm  GMT - Nibb Updated to half finished.<br />
Jun 6th 25 - 6:54pm  GMT - Nibb Completed almost . <br />
