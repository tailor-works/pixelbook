
use std::fs::File;
use std::fs;
use std::io::{self, BufReader, Read};
use std::io::BufWriter;
use std::io::Write;
use std::path::Path;

//mod error_checker;

#[derive(Debug, PartialEq, Clone, Copy)]
struct Point {
    x: i32,
    y: i32,
}



pub fn read_file(
    filepath: &str,
    separator: char,
) -> io::Result<Vec<String>> {
    let file = File::open(filepath)?;
    let mut reader = BufReader::new(file);
    let mut contents = String::new();

    // Read the entire file content into a String
    reader.read_to_string(&mut contents)?;

    // Split the string by the separator and collect into a Vec<String>
    let result: Vec<String> = contents
        .split(separator)
        .map(|s| s.trim().to_string()) // Trim whitespace and convert to String
        .collect();

    Ok(result)
}


pub fn createLocationDataGlow(){
    let mut filepath = "";
    filepath = "loc_dott.locf";
    let separator = ','; 
    let mut indexer:usize = 0;
    let mut arraystore: [u32;3] = [0,0,0];
    // Example list of points
     let mut points: Vec<Point> = vec![
    ];
    match read_file(filepath, separator) {
        Ok(data) => {
            for (i, item) in data.iter().enumerate() {
                let mut item2 = item.parse::<u32>().unwrap();
                indexer +=1;
                
                
                match indexer{
                    1 => arraystore[0] = item2,
                    2 => arraystore[1] = item2,
                    3 => arraystore[2] = item2,
                    _ => print!("unexpected")
                }
             
                if indexer == 3{
                    
                    indexer = 0;
                    
                    let new_point = Point { x: arraystore[0] as i32, y: arraystore[1] as i32 };
                    points.push(new_point);
                    
                }
            }
        }
        Err(e) => {
            eprintln!("Error reading file: {}", e);
        }

    }
    
   

    let mut filename = "";
    filename = "loc_glow.locf";

    let mut file_write = File::create(filename).expect("Cannot create file");


 
    let mut arraystoreOutline: [i32;3] =[0,0,0];
    //outline maker
    let mut arraystoreOutlineN: [i32;3] =[0,0,0];
    let mut arraystoreOutlineS: [i32;3] =[0,0,0];
    let mut arraystoreOutlineE: [i32;3] =[0,0,0];
    let mut arraystoreOutlineW: [i32;3] =[0,0,0];
    // If you don't want to close the shape, you can iterate like this:
   
    
    
    for i in 0..(points.len() - 1) {
        let mut pointsC = points[i];
        pointsC.x +=1;
        
      
        arraystoreOutlineS[0] = pointsC.x;
        arraystoreOutlineS[1] = pointsC.y;
        arraystoreOutlineS[2] = 0;

        writeln!(
            file_write,
            "{},{},{},", // This is your format string literal
            arraystoreOutlineS[0], // First argument for the first {}
            arraystoreOutlineS[1], // Second argument for the second {}
            arraystoreOutlineS[2], // Third argument for the third {}
    
        ).expect("Can't write to file"); // Make sure your expect message is complete
    }
    
    for i in 0..(points.len() - 1) {
        let mut pointsE = points[i];

        pointsE.y +=1;
      
        arraystoreOutlineW[0] = pointsE.x;
        arraystoreOutlineW[1] = pointsE.y;
        arraystoreOutlineW[2] = 0;

        writeln!(
            file_write,
            "{},{},{},", // This is your format string literal
            arraystoreOutlineW[0], // First argument for the first {}
            arraystoreOutlineW[1], // Second argument for the second {}
            arraystoreOutlineW[2], // Third argument for the third {}
    
        ).expect("Can't write to file"); // Make sure your expect message is complete
    }


for i in 0..(points.len() - 1) {
        let mut pointsC = points[i];
        pointsC.x -=1;
        
      
        arraystoreOutlineS[0] = pointsC.x;
        arraystoreOutlineS[1] = pointsC.y;
        arraystoreOutlineS[2] = 0;

        writeln!(
            file_write,
            "{},{},{},", // This is your format string literal
            arraystoreOutlineS[0], // First argument for the first {}
            arraystoreOutlineS[1], // Second argument for the second {}
            arraystoreOutlineS[2], // Third argument for the third {}
    
        ).expect("Can't write to file"); // Make sure your expect message is complete
    }
    
    for i in 0..(points.len() - 1) {
        let mut pointsE = points[i];

        pointsE.y -=1;
      
        arraystoreOutlineW[0] = pointsE.x;
        arraystoreOutlineW[1] = pointsE.y;
        arraystoreOutlineW[2] = 0;

        writeln!(
            file_write,
            "{},{},{},", // This is your format string literal
            arraystoreOutlineW[0], // First argument for the first {}
            arraystoreOutlineW[1], // Second argument for the second {}
            arraystoreOutlineW[2], // Third argument for the third {}
    
        ).expect("Can't write to file"); // Make sure your expect message is complete
    }


    remove_(filename);

 

}

fn remove_<P: AsRef<Path>>(filename: P) -> io::Result<()> {
    // 1. Read the file's content
    let mut content = fs::read_to_string(&filename)?;

    // 2. Check for a trailing comma and 3. Remove it
    if content.ends_with(',') {
        content.pop(); // Remove the last character (the comma)
        
        
    } else if content.ends_with(",\n") {
        // If it's a comma followed by a newline, remove both then add newline back
        content.pop(); // removes newline
        content.pop(); // removes comma
        content.push_str("\n"); // add newline back after removing the comma
        
    }
    else {
        println!("No trailing comma found in file: {}", filename.as_ref().display());
    }

    // 4. Write the modified content back to the file
    let mut file = fs::File::create(&filename)?; // Create will truncate (clear) the file
    file.write_all(content.as_bytes())?;
    //error_checker::checkData();
    println!("data sort complete ...");
    Ok(())
}
