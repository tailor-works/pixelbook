use image::{GenericImageView, ImageBuffer, Rgba};
use std::path::Path;
use std::io;

pub fn cutter() -> io::Result<()> {
    // --- Configuration ---
    let input_filename = "output.png"; // Replace with your input PNG filename
    let output_filename_top = "output_shine.png";
    let output_filename_bottom = "output_shadow.png";
    // --- End Configuration ---

    println!("Attempting to split '{}' horizontally...", input_filename);

    // 1. Open the image
    let img = image::open(&Path::new(input_filename))
        .map_err(|e| io::Error::new(io::ErrorKind::Other, format!("Failed to open image: {}", e)))?;

    let (width, height) = img.dimensions();
    println!("Image dimensions: {}x{}", width, height);

    // Calculate the midpoint for horizontal split
    let mid_height = height / 2;

    // 2. Create two new image buffers for the halves
    let mut top_half = ImageBuffer::<Rgba<u8>, Vec<u8>>::new(width, mid_height);
    let mut bottom_half = ImageBuffer::<Rgba<u8>, Vec<u8>>::new(width, height - mid_height);

    // 3. Iterate over pixels and copy them to the respective halves
    for y in 0..height {
        for x in 0..width {
            let pixel = img.get_pixel(x, y);
            if y < mid_height {
                // Top half
                top_half.put_pixel(x, y, pixel);
            } else {
                // Bottom half (adjust y coordinate for the new buffer)
                bottom_half.put_pixel(x, y - mid_height, pixel);
            }
        }
    }

    // 4. Save the new images
    top_half.save(output_filename_top)
        .map_err(|e| io::Error::new(io::ErrorKind::Other, format!("Failed to save top half: {}", e)))?;
    println!("Successfully saved top half to '{}'", output_filename_top);

    bottom_half.save(output_filename_bottom)
        .map_err(|e| io::Error::new(io::ErrorKind::Other, format!("Failed to save bottom half: {}", e)))?;
    println!("Successfully saved bottom half to '{}'", output_filename_bottom);

    println!("\nProcess complete!");

    Ok(())
}