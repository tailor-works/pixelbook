use image::{GenericImageView, ImageBuffer, Rgba};
use std::path::Path;

pub fn joine() {
    // Define the paths to your input images and the output image
    let img1_path = Path::new("lightened_image_white_to_alpha.png");
    let img2_path = Path::new("output_shadow_adjusted.png");
    let output_path = Path::new("combined_image.png");

    // 1. Load the first image
    let img1 = match image::open(&img1_path) {
        Ok(img) => img.to_rgba8(), // Convert to RGBA8 for consistent pixel format
        Err(e) => {
            eprintln!("Error opening {}: {}", img1_path.display(), e);
            return;
        }
    };

    // 2. Load the second image
    let img2 = match image::open(&img2_path) {
        Ok(img) => img.to_rgba8(), // Convert to RGBA8
        Err(e) => {
            eprintln!("Error opening {}: {}", img2_path.display(), e);
            return;
        }
    };

    // Get dimensions of both images
    let (width1, height1) = img1.dimensions();
    let (width2, height2) = img2.dimensions();

    // 3. Calculate new dimensions for the combined image
    // The width will be the maximum of the two input image widths
    let new_width = width1.max(width2);
    // The height will be the sum of the two input image heights
    let new_height = height1 + height2;

    // 4. Create a new image buffer with the calculated dimensions, filled with transparent black
    // Rgba<u8> means Red, Green, Blue, Alpha, each component as an 8-bit unsigned integer
    let mut combined_img = ImageBuffer::<Rgba<u8>, Vec<u8>>::new(new_width, new_height);

    // 5. Copy the first image onto the top section of the new image
    for y in 0..height1 {
        for x in 0..width1 {
            // Get the pixel from the first image
            let pixel = img1.get_pixel(x, y);
            // Put the pixel into the combined image at the same (x, y) coordinates
            combined_img.put_pixel(x, y, *pixel);
        }
    }

    // 6. Copy the second image directly below the first image
    // The y-coordinate for the second image will be offset by the height of the first image
    for y in 0..height2 {
        for x in 0..width2 {
            // Get the pixel from the second image
            let pixel = img2.get_pixel(x, y);
            // Put the pixel into the combined image, offsetting y by `height1`
            combined_img.put_pixel(x, y + height1, *pixel);
        }
    }

    // 7. Save the combined image to a new PNG file
    match combined_img.save(&output_path) {
        Ok(_) => println!("Successfully combined images and saved to {}", output_path.display()),
        Err(e) => eprintln!("Error saving combined image: {}", e),
    }
}