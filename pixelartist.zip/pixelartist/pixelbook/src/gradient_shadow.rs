use image::{GenericImageView, ImageBuffer, Rgba};
use std::path::Path;
use std::error::Error;

pub fn gradshadow2() -> Result<(), Box<dyn Error>> {
    let original_img_path = "output_shine_adjusted.png";

    // --- 1. Load the Original Image (with its alpha channel) ---
    let original_img = image::open(&Path::new(original_img_path))?
        .to_rgba8();

    let (width, height) = original_img.dimensions();
    println!("Original image dimensions: {}x{}", width, height);

    // --- Gradient Center, Radius, and Steepness Adjustment Variables ---
    // These define where the center of the sphere gradient will be.
    // Values are in pixels.
    let gradient_center_x: f32 = width as f32 / 2.0;
    let gradient_center_y: f32 = height as f32 / 2.0;

    // This controls how large (or small) the visible part of the gradient is.
    // A smaller value makes the gradient more localized.
    let gradient_radius: f32 = width as f32 / 3.0;

    // This controls the "sharpness" or "falloff" of the gradient.
    // A value of 1.0 (linear) is default.
    // Values > 1.0 make the gradient steeper (more abrupt fade).
    // Values < 1.0 (e.g., 0.5) make the gradient softer/more gradual.
    let gradient_steepness: f32 = 2.0; // Try 2.0, 3.0, 4.0 for steeper effects

    println!("Gradient center set to: ({}, {})", gradient_center_x, gradient_center_y);
    println!("Gradient radius set to: {}", gradient_radius);
    println!("Gradient steepness set to: {}", gradient_steepness);


    // --- 2. Generate the Sphere Gradient Image for Subtraction ---
    // This gradient will be pure white (255,255,255) but its alpha channel
    // will vary from opaque (255) at the center to transparent (0) at the edges.
    let mut gradient_image: ImageBuffer<Rgba<u8>, Vec<u8>> = ImageBuffer::new(width, height);

    for y in 0..height {
        for x in 0..width {
            let dx = x as f32 - gradient_center_x;
            let dy = y as f32 - gradient_center_y;
            let distance = (dx.powi(2) + dy.powi(2)).sqrt();

            let mut normalized_dist = distance / gradient_radius;

            // Apply steepness (power function) here
            normalized_dist = normalized_dist.powf(gradient_steepness);

            // Calculate alpha value:
            // It goes from opaque (255) at center to transparent (0) at `gradient_radius`.
            let alpha_val = (255.0 * (1.0 - normalized_dist))
                                .min(255.0) // Clamp upper bound
                                .max(0.0)   // Clamp lower bound
                                as u8;

            // R, G, B channels are always 255 (white)
            // Alpha channel is the calculated `alpha_val`
            gradient_image.put_pixel(x, y, Rgba([255, 255, 255, alpha_val]));
        }
    }
    gradient_image.save("generated_sphere_gradient_for_subtraction.png")?;
    println!("Generated sphere gradient for subtraction saved to: generated_sphere_gradient_for_subtraction.png");

    // --- 3. Subtract the Gradient from the Original Image (preserving original alpha) ---
    // We'll use a similar blending logic as before, but for subtraction.
    let mut subtracted_image: ImageBuffer<Rgba<u8>, Vec<u8>> = ImageBuffer::new(width, height);

    for y in 0..height {
        for x in 0..width {
            let original_pixel = original_img.get_pixel(x, y);
            let gradient_pixel = gradient_image.get_pixel(x, y); // This is pure white with varying alpha

            let alpha_factor = gradient_pixel[3] as f32 / 255.0; // Gradient's alpha (0.0 to 1.0)

            let r_orig = original_pixel[0] as f32;
            let g_orig = original_pixel[1] as f32;
            let b_orig = original_pixel[2] as f32;

            // For subtraction, we're effectively subtracting a portion of white.
            // The amount of white to subtract is scaled by the gradient's alpha.
            let r_sub = (gradient_pixel[0] as f32) * alpha_factor;
            let g_sub = (gradient_pixel[1] as f32) * alpha_factor;
            let b_sub = (gradient_pixel[2] as f32) * alpha_factor;

            // Perform subtraction with clamping to 0 (saturating_sub equivalent for floats)
            let r = (r_orig - r_sub).min(255.0).max(0.0) as u8;
            let g = (g_orig - g_sub).min(255.0).max(0.0) as u8;
            let b = (b_orig - b_sub).min(255.0).max(0.0) as u8;

            // Keep the alpha channel from the original image
            let a = original_pixel[3];

            subtracted_image.put_pixel(x, y, Rgba([r, g, b, a]));
        }
    }

    // --- 4. Save the Resulting Subtracted Image ---
    let output_path = "subtracted_image_sphere_gradient.png";
    subtracted_image.save(output_path)?;
    println!("Subtracted image (with steeper sphere gradient) saved to: {}", output_path);

    Ok(())
}

// Your main function that calls grad()
pub fn gradshadow() {
    if let Err(e) = gradshadow2() {
        eprintln!("Error during gradient operation: {}", e);
    }
}