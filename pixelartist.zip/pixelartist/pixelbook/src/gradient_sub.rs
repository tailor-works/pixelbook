use image::{GenericImageView, ImageBuffer, Rgba};
use std::path::Path;
use std::error::Error;

pub fn grad() -> Result<(), Box<dyn Error>> {
    let original_img_path = "output_shine_adjusted.png";

    // --- 1. Load the Original Image (with its alpha channel) ---
    let original_img = image::open(&Path::new(original_img_path))?
        .to_rgba8();

    let (width, height) = original_img.dimensions();
    println!("Original image dimensions: {}x{}", width, height);

    // --- Gradient Center, Radius, and Steepness Adjustment Variables ---
    // These define where the center of the sphere gradient will be.
    // Values are in pixels.
    let gradient_center_x: f32 = width as f32 / 3.0;
    let gradient_center_y: f32 = height as f32 / 3.0;

    // This controls how large (or small) the visible part of the gradient is.
    // A smaller value makes the gradient more localized.
    let gradient_radius: f32 = width as f32 / 3.0;

    // This controls the "sharpness" or "falloff" of the gradient.
    // A value of 1.0 (linear) is default.
    // Values > 1.0 make the gradient steeper (more abrupt fade).
    // Values < 1.0 (e.g., 0.5) make the gradient softer/more gradual.
    let gradient_steepness: f32 = 2.0; // Try 2.0, 3.0, 4.0 for steeper effects

    println!("Gradient center set to: ({}, {})", gradient_center_x, gradient_center_y);
    println!("Gradient radius set to: {}", gradient_radius);
    println!("Gradient steepness set to: {}", gradient_steepness);


    // --- 2. Generate the Sphere Gradient Image for Addition ---
    let mut gradient_image: ImageBuffer<Rgba<u8>, Vec<u8>> = ImageBuffer::new(width, height);

    for y in 0..height {
        for x in 0..width {
            let dx = x as f32 - gradient_center_x;
            let dy = y as f32 - gradient_center_y;
            let distance = (dx.powi(2) + dy.powi(2)).sqrt();

            let mut normalized_dist = distance / gradient_radius;

            // Apply steepness (power function) here
            normalized_dist = normalized_dist.powf(gradient_steepness);

            // Calculate alpha value:
            // It goes from opaque (255) at center to transparent (0) at `gradient_radius`.
            // Pixels beyond `gradient_radius` will have an alpha of 0.
            let alpha_val = (255.0 * (1.0 - normalized_dist))
                                .min(255.0) // Clamp upper bound
                                .max(0.0)   // Clamp lower bound
                                as u8;

            gradient_image.put_pixel(x, y, Rgba([255, 255, 255, alpha_val]));
        }
    }
    gradient_image.save("generated_sphere_gradient_steeper.png")?;
    println!("Generated steeper sphere gradient saved to: generated_sphere_gradient_steeper.png");

    // --- 3. Add the Gradient to the Original Image (preserving original alpha) ---
    let mut lightened_image: ImageBuffer<Rgba<u8>, Vec<u8>> = ImageBuffer::new(width, height);

    for y in 0..height {
        for x in 0..width {
            let original_pixel = original_img.get_pixel(x, y);
            let gradient_pixel = gradient_image.get_pixel(x, y);

            let alpha_factor = gradient_pixel[3] as f32 / 255.0;

            let r_orig = original_pixel[0] as f32;
            let g_orig = original_pixel[1] as f32;
            let b_orig = original_pixel[2] as f32;

            let r_grad = gradient_pixel[0] as f32;
            let g_grad = gradient_pixel[1] as f32;
            let b_grad = gradient_pixel[2] as f32;

            let r = (r_orig + r_grad * alpha_factor).min(255.0).max(0.0) as u8;
            let g = (g_orig + g_grad * alpha_factor).min(255.0).max(0.0) as u8;
            let b = (b_orig + b_grad * alpha_factor).min(255.0).max(0.0) as u8;

            let a = original_pixel[3];

            lightened_image.put_pixel(x, y, Rgba([r, g, b, a]));
        }
    }

    // --- 4. Save the Resulting Lightened Image ---
    let output_path = "lightened_image_sphere_gradient_steeper.png";
    lightened_image.save(output_path)?;
    println!("Lightened image (with steeper sphere gradient) saved to: {}", output_path);

    Ok(())
}

// Your main function that calls grad()
pub fn gradi() {
    if let Err(e) = grad() {
        eprintln!("Error during gradient operation: {}", e);
    }
}