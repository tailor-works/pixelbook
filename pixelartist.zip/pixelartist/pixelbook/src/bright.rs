use image::{DynamicImage, GenericImageView, ImageBuffer, Rgba};
use std::path::Path;
use std::process;

pub fn shine() {
    // --- Configuration ---
    let input_path = "output.png"; // Make sure you have an 'input.png' in the same directory
    let output_path = "output_shine_adjusted.png";
    let brightness_value: i32 = 50; // Positive for brighter, negative for darker (e.g., -50 to 50 or more)
    let contrast_value: f32 = 1.6;   // > 1.0 for more contrast, < 1.0 for less contrast (e.g., 0.5 to 2.0)
                                    // 1.0 means no change

    println!("Attempting to adjust image brightness and contrast...");
    println!("Input: {}", input_path);
    println!("Output: {}", output_path);
    println!("Brightness: {}", brightness_value);
    println!("Contrast: {}", contrast_value);

    // 1. Load the image
    let mut img = match image::open(input_path) {
        Ok(img) => {
            println!("Image loaded successfully!");
            img
        }
        Err(e) => {
            eprintln!("Error: Could not load image from '{}': {}", input_path, e);
            eprintln!("Please ensure 'input.png' exists in the same directory as the executable.");
            process::exit(1);
        }
    };

    // Ensure the image is in a modifiable format (e.g., RGBA8)
    let (width, height) = img.dimensions();
    let mut rgba_img = img.to_rgba8(); // Convert to RGBA8 for pixel manipulation

    // 2. Adjust Brightness and Contrast
    // Note: Applying brightness then contrast (or vice versa) can slightly alter results.
    // This order is common.

    for y in 0..height {
        for x in 0..width {
            let pixel = rgba_img.get_pixel_mut(x, y);

            // Get individual color components (R, G, B)
            let r = pixel[0] as f32;
            let g = pixel[1] as f32;
            let b = pixel[2] as f32;

            // --- Apply Brightness ---
            // Add or subtract directly to each color channel.
            let mut new_r = r + brightness_value as f32;
            let mut new_g = g + brightness_value as f32;
            let mut new_b = b + brightness_value as f32;

            // Clamp values to stay within 0-255 range
            new_r = new_r.max(0.0).min(255.0);
            new_g = new_g.max(0.0).min(255.0);
            new_b = new_b.max(0.0).min(255.0);

            // --- Apply Contrast ---
            // This is a common formula: `new_color = (color - 128) * contrast_factor + 128`
            // 128 is the midpoint of the 0-255 range.
            new_r = (new_r - 128.0) * contrast_value + 128.0;
            new_g = (new_g - 128.0) * contrast_value + 128.0;
            new_b = (new_b - 128.0) * contrast_value + 128.0;

            // Clamp values again after contrast adjustment
            new_r = new_r.max(0.0).min(255.0);
            new_g = new_g.max(0.0).min(255.0);
            new_b = new_b.max(0.0).min(255.0);

            // Update the pixel
            pixel[0] = new_r as u8;
            pixel[1] = new_g as u8;
            pixel[2] = new_b as u8;
            // pixel[3] (alpha channel) remains unchanged
        }
    }

    // Convert back to DynamicImage if necessary for saving, or directly save RGBA8
    let adjusted_img: DynamicImage = DynamicImage::ImageRgba8(rgba_img);

    // 3. Save the modified image
    match adjusted_img.save(output_path) {
        Ok(_) => println!("Image successfully saved to '{}'", output_path),
        Err(e) => eprintln!("Error: Could not save image to '{}': {}", output_path, e),
    }
}