use image::{io::Reader as ImageReader, DynamicImage, ImageError, Rgba};
use std::path::Path;
use std::error::Error; // Import the Error trait

use std::fs::File;
use std::fs;
use std::io::{self, BufReader, Read};
use std::io::BufWriter;
use std::io::Write;

fn main() {
    let mut filename = "";
    filename = "loc_dott.locf";

  
    load_image();
}
fn load_image() {
    let mut file_write = File::create("output.txt").expect("Failed to create or open output.txt");
    let mut rgba_img_buffer = image::open("image.png").unwrap().to_rgba8();
    let mut ax : u32;
    let mut maxx : u32;
    let mut maxy : u32;
    
    maxx = 64;
    maxy = 64;
    let mut ay : u32;
    ax = 0;
    ay = 0;
    while maxy -1 > ay{
    let mut zlayer :u32;
    zlayer = 0;
    
    while maxx -1 > ax{
        ax +=1;
        if ax > maxx-2 {
        
        ax = 0;
        ay+=1;
    } else {
        println!("");
    }
    // Accessing a pixel from the new buffer
    let mut specific_pixel_from_buffer = rgba_img_buffer.get_pixel(ax, ay);
    println!("Pixel at ({}, {}) from RGBA8 buffer: {:?}", ax, ay, specific_pixel_from_buffer.0);
    if specific_pixel_from_buffer.0[3] == 255 {
        writeln!(
            file_write,
            "{},{},{},", // This is your format string literal
            ax, // First argument for the first {}
            ay, // Second argument for the second {}
            zlayer, // Third argument for the third {}
    
        ).expect("Can't write to file"); // Make sure your expect message is complete
        }
    }
        
        }

}




    
